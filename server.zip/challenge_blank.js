const express = require('express');
const request = require('request');

var app = express();
var weather = ''; //variable to hold the weather info

app.use(express.static(__dirname + '/public'));

// here add routes

app.listen(8080, () => {
    console.log('Server is up on the port 8080');
    // here add the logic to return the weather and save it inside the weather variable
});